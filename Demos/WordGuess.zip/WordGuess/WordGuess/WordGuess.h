//
//  WordGuess.h
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <vector>

NSArray* getAllPossibleWords(const std::vector<char>& characters,int wordLength);

void initWordHelper();