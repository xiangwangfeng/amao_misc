//
//  WidgetNode.m
//  VirtualNodeDemo
//
//  Created by amao on 2020/1/8.
//  Copyright © 2020 amao. All rights reserved.
//

#import "WidgetNode.h"

@implementation WidgetNode

- (instancetype)init
{
    if (self = [super init])
    {
        _children = [NSMutableArray array];
    }
    return self;
}


- (UIView *)nodeView
{
    UIView *view = [UIView new];
    view.backgroundColor = [WidgetNode backgroundColorByIndex:self.backgroundColorIndex];
    view.frame = self.frame;
    for (WidgetNode *node in self.children)
    {
        UIView *subView = [node nodeView];
        [view addSubview:subView];
    }
    return view;
}


- (void)updateView:(UIView *)view
{
    view.backgroundColor = [WidgetNode backgroundColorByIndex:self.backgroundColorIndex];
    view.frame = self.frame;
    
    NSInteger subviewCount = view.subviews.count;
    NSInteger subNodeCount = self.children.count;
    NSAssert(subviewCount == subNodeCount, @"invalid");
    for (NSInteger i = 0; i < subviewCount; i++) {
        WidgetNode *node = self.children[i];
        UIView *subView = view.subviews[i];
        [node updateView:subView];
    }
}


+ (UIColor *)backgroundColorByIndex:(NSInteger)index
{
    static NSArray<UIColor *> *colors = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        colors = @[UIColor.redColor,
        UIColor.blackColor,
        UIColor.blueColor,
        UIColor.brownColor,
        UIColor.cyanColor,
        UIColor.greenColor];
    });
    return colors[index % colors.count];
}
@end
