//
//  StaticLibrary.m
//  StaticLibrary
//
//  Created by amao on 2016/10/14.
//  Copyright © 2016年 amao. All rights reserved.
//

#import "StaticLibrary.h"
#import "ClassA.h"

@implementation StaticLibrary

- (void)say
{
    ClassA *z = [[ClassA alloc] init];
    [z say];
}
@end
