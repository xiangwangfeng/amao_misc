//
//  HelloC.c
//  StaticLibrary
//
//  Created by amao on 2016/10/14.
//  Copyright © 2016年 amao. All rights reserved.
//

#include "HelloC.h"

void SayHello()
{
    printf("\nsay hello in  static library\n");
}
