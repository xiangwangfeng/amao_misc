//
//  TrieTree.h
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//
#ifndef TRIE_TREE_H
#define TRIE_TREE_H

#include <string>

struct TrieTreeNode 
{
	TrieTreeNode *children_[26];
	bool		 child_is_word_[26];
	TrieTreeNode()
	{
		for (int i = 0; i < 26;i++)
		{
			children_[i] = 0;
			child_is_word_[i] = false;
		}
	}
	~TrieTreeNode()
	{
		for (int i = 0; i < 26;i++)
		{
			delete children_[i];
		}
	}
};

class TrieTree
{
public:
	TrieTree();
	~TrieTree();
public:
	void AddWord(const std::string &word);	
	bool Contains(const std::string &word,bool is_a_whole_word = false);	
	void ReadDicFromFile(const char *filepath);
private:
	void AddWord(TrieTreeNode *node,const std::string &word,size_t index_of_character);
	bool Contains(TrieTreeNode *node,const std::string &word,size_t index_of_character,bool is_a_whole_word);

	void MakeLowerCase(const std::string &input,std::string &output);
	bool ContainsLowerCaseWordOnly(const std::string &input);


private:
	TrieTreeNode	*header_;
};


#endif
