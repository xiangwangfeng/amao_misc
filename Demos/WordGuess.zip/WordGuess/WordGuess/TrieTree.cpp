//
//  WordHelper.cpp
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//


#include "TrieTree.h"
#include <algorithm>

TrieTree::TrieTree()
{
	header_ = new TrieTreeNode;
}


TrieTree::~TrieTree()
{
	delete header_;
}

void	TrieTree::AddWord(const std::string &word)
{
	std::string lowercase_word;
	MakeLowerCase(word,lowercase_word);
	if (ContainsLowerCaseWordOnly(lowercase_word))
	{
		AddWord(header_,lowercase_word,0);
	}
}

void	TrieTree::AddWord(TrieTreeNode *node,const std::string &word,size_t index_of_character)
{
	char ch = word.at(index_of_character);
	int index = ch - 'a';
	if (node->children_[index] == 0)
	{
		node->children_[index] = new TrieTreeNode;
	}

	if (index_of_character + 1 == word.length())
	{
		node->child_is_word_[index] = true;
		return;
	}
	AddWord(node->children_[index],word,index_of_character + 1);
}

bool	TrieTree::Contains(const std::string &word,bool is_a_whole_word)
{
	std::string lowercase_word;
	MakeLowerCase(word,lowercase_word);

	return ContainsLowerCaseWordOnly(lowercase_word) && 
			Contains(header_,lowercase_word,0,is_a_whole_word);
}

bool	TrieTree::Contains(TrieTreeNode *node,const std::string &word,size_t index_of_character,bool is_a_whole_word)
{

	char ch = word.at(index_of_character);
	int index = ch - 'a';

	if (index_of_character + 1 == word.length())
	{
		return node->children_[index] != 0 && 
			(!is_a_whole_word || node->child_is_word_[index]);
	}
	else
	{
		return node->children_[index] != 0 && 
			Contains(node->children_[index],word,index_of_character + 1,is_a_whole_word);
	}
}

void	TrieTree::MakeLowerCase(const std::string &input,std::string &output)
{
	size_t length = input.length();
	if (length)
	{
		output.resize(length);
		std::transform(input.begin(),input.end(),output.begin(),tolower);
	}
}

bool	TrieTree::ContainsLowerCaseWordOnly(const std::string &input)
{
	for (size_t i = 0; i < input.length(); i++)
	{
		char ch = input.at(i);
		if (!(ch >= 'a' && ch <= 'z'))
		{
			return false;
		}
	}
	return true;
}


void	TrieTree::ReadDicFromFile(const char *filepath)
{
	FILE *file = fopen(filepath,"r");
	if (file)
	{
		char word[256] = {0};
		while (fgets(word,256,file))
		{
			std::string valid_word(word);
			size_t index = valid_word.find("\n");
			if (index != std::string::npos)
			{
				valid_word = valid_word.substr(0,index);
			}
			AddWord(valid_word);
		}

		fclose(file);
	}
}