//
//  ClassA.m
//  StaticLibrary
//
//  Created by amao on 2016/10/14.
//  Copyright © 2016年 amao. All rights reserved.
//

#import "ClassA.h"
#import "HelloC.h"

@implementation ClassA

- (instancetype)init
{
    if (self = [super init])
    {
        NSLog(@"I'm a class in static library");
    }
    return self;
}

- (void)say
{
    SayHello();
}
@end
