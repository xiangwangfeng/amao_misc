document.onreadystatechange = ()=> {
    if(document.readyState == 'complete')
    {
        const button = document.getElementById('login')
        button.addEventListener('click',()=>{
            const username = document.getElementById('username')
            const password = document.getElementById('password')
            let data = {'username' : username.value,
                        'password' : password.value}
            console.log('begin')
            fetch('/login',{
                method : 'Post',
                body : JSON.stringify(data),
                headers : {
                    'Content-Type'  : 'application/json'
                },
                credentials : 'include',
            }).then(res => {
                res.text().then(function(text){
                if(text == '200')
                {
                    window.location.href = '/'
                }
                else
                {
                    window.location.href = '/login_failed'
                }
            })})
        });
    }
}