//
//  M80ImageMergeInfo.m
//  M80Image
//
//  Created by amao on 11/18/15.
//  Copyright © 2015 Netease. All rights reserved.
//

#import "M80ImageMergeInfo.h"
#import "M80ImageFingerprint.h"

@implementation M80ImageMergeInfo
@end


@interface M80ImageMergeInfoGenerator ()
@property (nonatomic,assign)    NSRange firstMatchedRange;
@property (nonatomic,assign)    NSRange secondMatchedRange;
@end


@implementation M80ImageMergeInfoGenerator
- (instancetype)init
{
    if (self = [super init])
    {
        _firstMatchedRange = NSMakeRange(0, 0);
        _secondMatchedRange = NSMakeRange(0, 0);
    }
    return self;
}


/*
- (M80ImageMergeInfo *)infoByImage:(UIImage *)firstImage
                       secondImage:(UIImage *)secondImage
{
    M80ImageMergeInfo *info = [[M80ImageMergeInfo alloc] init];
    info.firstImage = firstImage;
    info.secondImage = secondImage;
    
    
    M80ImageFingerprint *firstFingerprint = [M80ImageFingerprint fingerprint:firstImage];
    M80ImageFingerprint *secondFingerprint= [M80ImageFingerprint fingerprint:secondImage];
    NSArray *firstLines = [firstFingerprint lines];
    NSArray *secondLines= [secondFingerprint lines];
    
    NSInteger firstCountEnd     = [firstLines count];
    NSInteger firstCountBegin   = 0;
    NSInteger secondCountBegin  = 0;
    NSInteger secondCountEnd    = [secondLines count];
    
    
    
    
    NSLog(@"compare begin");
    for (NSInteger  i = firstCountBegin; i < firstCountEnd; i++)
    {
        for (NSInteger j = secondCountBegin; j < secondCountEnd;  j++)
        {
            long long first = [[firstLines objectAtIndex:i] longLongValue];
            long long second= [[secondLines objectAtIndex:j] longLongValue];
            
            if (first == second)
            {
                NSInteger firstBegin = i,secondBegin = j;
                NSInteger end = i;
                for (NSInteger m = i,n = j; m < firstCountEnd && n < secondCountEnd; m ++,n++)
                {
                    if ( [[firstLines objectAtIndex:m] longLongValue] == [[secondLines objectAtIndex:n] longLongValue])
                    {
                        end++;
                    }
                    else
                    {
                        break;
                    }
                }
                NSInteger length = end - firstBegin;
                if (length > _firstMatchedRange.length)
                {
                    _firstMatchedRange = NSMakeRange(firstBegin, length);
                    _secondMatchedRange= NSMakeRange(secondBegin, length);
                }
                
            }
        }
    }
    
    info.firstMatchedRange = _firstMatchedRange;
    info.secondMatchedRange= _secondMatchedRange;
    info.size = CGSizeMake(firstImage.size.width, _firstMatchedRange.location + secondImage.size.height - _secondMatchedRange.location);
    NSLog(@"compare end");
    return info;
}*/


- (M80ImageMergeInfo *)infoByImage:(UIImage *)firstImage
                       secondImage:(UIImage *)secondImage
{
    M80ImageMergeInfo *info = [[M80ImageMergeInfo alloc] init];
    info.firstImage = firstImage;
    info.secondImage = secondImage;
    
    
    M80ImageFingerprint *firstFingerprint = [M80ImageFingerprint fingerprint:firstImage];
    M80ImageFingerprint *secondFingerprint= [M80ImageFingerprint fingerprint:secondImage];
    NSArray *firstLines = [firstFingerprint lines];
    NSArray *secondLines= [secondFingerprint lines];
    

    NSLog(@"compare begin");
    int **matrix = new int*[[firstLines count]];
    for (int i = 0; i < [firstLines count]; i++) {
        matrix[i] = new int[[secondLines count]];
    }
    
    
    
    long long firstValueInSecondLines = [[secondLines firstObject] longLongValue];
    for (NSInteger i = 0; i < [firstLines count]; i++)
    {
        long long value = [[firstLines objectAtIndex:i] longLongValue];
        matrix[i][0] = value == firstValueInSecondLines;
    }
    long long firstValueInFirstLines = [[firstLines firstObject] longLongValue];
    for (NSInteger  i = 0; i < [secondLines count]; i++)
    {
        long long value = [[secondLines objectAtIndex:i] longLongValue];
        matrix[0][i] = value == firstValueInFirstLines;
    }
    
    NSInteger length = 0,x = 0,y = 0;
    for (NSInteger i = 1 ; i < [firstLines count]; i ++)
    {
        for (NSInteger  j = 1; j < [secondLines count]; j++)
        {
            if ([[firstLines objectAtIndex:i] longLongValue] == [[secondLines objectAtIndex:j] longLongValue])
            {
                int value = matrix[i-1][j-1]+ 1;
                matrix[i][j] = value;
                if (value > length)
                {
                    length = value;
                    x = i;
                    y = j;
                }
                
            }
            else
            {
                matrix[i][j]= 0;
            }
        }
    }
    
    for (int i = 0; i < [firstLines count]; ++i)
        delete [] matrix[i];
    delete [] matrix;
    
    info.firstMatchedRange = NSMakeRange(x - length + 1, length);
    info.secondMatchedRange= NSMakeRange(y - length + 1, length);
    info.size = CGSizeMake(firstImage.size.width, info.firstMatchedRange.location + secondImage.size.height - info.secondMatchedRange.location);
    NSLog(@"compare end");
    return info;
}
@end