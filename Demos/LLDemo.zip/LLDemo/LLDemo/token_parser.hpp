//
//  token_parser.hpp
//  LLDemo
//
//  Created by amao on 2020/1/13.
//  Copyright © 2020 amao. All rights reserved.
//

#ifndef token_parser_hpp
#define token_parser_hpp

#include <stdio.h>
#include <vector>
#include <string>

enum TokenType {
    kTokenTypeAdd,
    kTokenTypeMinus,
    kTokenTypeMul,
    kTokenTypeDiv,
    kTokenNumber,
    kTokenLP,
    kTokenRP,
};


struct Token
{
    TokenType type_;
    double value_;
};


class TokenParser
{
public:
    static  std::vector<Token> parse(const std::string &exp);
private:
    static  double parse_number(const std::string &exp,size_t *index);
};

#endif /* token_parser_hpp */
