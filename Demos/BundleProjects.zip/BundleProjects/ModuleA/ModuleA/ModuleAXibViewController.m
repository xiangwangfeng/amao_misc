//
//  ModuleAXibViewController.m
//  ModuleA
//
//  Created by amao on 16/1/31.
//  Copyright © 2016年 NTES. All rights reserved.
//

#import "ModuleAXibViewController.h"

@interface ModuleAXibViewController ()

@end

@implementation ModuleAXibViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Xib ViewController";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
