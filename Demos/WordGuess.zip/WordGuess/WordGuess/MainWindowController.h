//
//  MainWindowController.h
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MainWindowController : NSWindowController

@property (assign) IBOutlet NSTextField *wordTextField;
@property (assign) IBOutlet NSTextField *wordNumTextField;
@property (retain) NSArray	*possibleWords;
@property (assign) IBOutlet NSTableView *wordsTableView;
@property (assign) IBOutlet NSTextField *errorLabel;

- (IBAction)onBeginSearchButtonPressed:(id)sender;

@end
