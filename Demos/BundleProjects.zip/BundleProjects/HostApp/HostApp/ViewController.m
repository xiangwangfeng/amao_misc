//
//  ViewController.m
//  HostApp
//
//  Created by amao on 16/1/31.
//  Copyright © 2016年 NTES. All rights reserved.
//

#import "ViewController.h"
#import "ModuleAXibViewController.h"
#import "ModuleA.h"

@interface ViewController ()
@property (nonatomic,strong)    NSArray *items;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    _items = @[@"ModuleAViewController",@"ModuleBViewController",@"ModuleAXibViewController"];
    self.title = @"HostApp";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_items count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *text = [_items objectAtIndex:[indexPath row]];
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                   reuseIdentifier:@"test"];
    cell.textLabel.text = text;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *text = [_items objectAtIndex:[indexPath row]];
    if ([text isEqualToString:@"ModuleAXibViewController"])
    {
        NSBundle *bundle = [ModuleA bundle];
        ModuleAXibViewController *vc = [[ModuleAXibViewController alloc] initWithNibName:@"ModuleAXibViewController"
                                                                                  bundle:bundle];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else
    {
        Class cls = NSClassFromString(text);
        UIViewController *vc = [[cls alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    
}
@end
