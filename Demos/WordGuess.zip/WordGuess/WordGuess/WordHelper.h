//
//  WordHelper.h
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//

#ifndef WORD_HELPER_H
#define WORD_HELPER_H

#include <vector>
#include <string>
#include "TrieTree.h"


class WordHelper
{
public:
	WordHelper();
	~WordHelper();

	void InitDic(const char *filepath);
	void FindAllWords(const std::vector<char> &characters,size_t word_length,std::vector<std::string> &words);
private:
	void FindAllWords(const std::vector<char>& characters,size_t word_length,const std::string& word_header);
	void TryToPushStringToVector(const std::string &word);
	bool HasInvalidCharacter(const std::vector<char> &characters);
private:
	TrieTree	tree_;
	std::vector<std::string> *words_;
};

#endif

