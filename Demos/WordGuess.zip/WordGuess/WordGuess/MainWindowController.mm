//
//  MainWindowController.m
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//

#import "MainWindowController.h"
#import <vector>
#import <string>
#import "WordGuess.h"

@implementation MainWindowController
@synthesize wordTextField;
@synthesize wordNumTextField;
@synthesize possibleWords;
@synthesize wordsTableView;
@synthesize errorLabel;

- (id)initWithWindow:(NSWindow *)window
{
    self = [super initWithWindow:window];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (void)windowDidLoad
{
    [super windowDidLoad];
	[errorLabel setHidden:YES];
    
}

- (IBAction)onBeginSearchButtonPressed:(id)sender 
{
	[errorLabel setHidden:YES];
	NSString *characters = [[wordTextField stringValue] lowercaseString];
	NSInteger length     = [wordNumTextField intValue];
	
	NSString *ragex = @"[a-z]+";
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ragex];
	if ([predicate evaluateWithObject:characters]) 
	{
		std::vector<char>	words;
		const char *p = [characters UTF8String];
		for (size_t i  = 0; i < [characters length]; i++) 
		{
			words.push_back(*p);
			p++;
		}
		
		
		self.possibleWords = getAllPossibleWords(words,(int)length);
		[wordsTableView reloadData];
	}
	else
	{
		[errorLabel setHidden:NO];
	}
}


- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView 
{
	return [possibleWords count];
}


- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row 
{
    NSTableCellView *cellView = [tableView makeViewWithIdentifier:@"MyFirstCell" owner:self];
    cellView.textField.stringValue = [possibleWords objectAtIndex:row];
    return cellView;
   }

@end
