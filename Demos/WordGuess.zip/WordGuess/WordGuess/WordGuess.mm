//
//  WordGuess.m
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//

#import "WordGuess.h"
#import "WordHelper.h"

WordHelper	*helper = nil;

void initWordHelper()
{
	if (helper == nil) 
	{
		helper = new WordHelper();
		
		NSString *filepath = [[NSBundle mainBundle] pathForResource:@"wordlist" ofType:@"txt"];
		helper->InitDic([filepath UTF8String]);
	}
}

NSArray* getAllPossibleWords(const std::vector<char>& characters,int wordLength)
{
	initWordHelper();

	std::vector<std::string> words;
	helper->FindAllWords(characters, wordLength, words);	
	
	NSMutableArray *array = [[NSMutableArray alloc]init];
	for (size_t i = 0; i < words.size(); i++) 
	{
		NSString *word = [NSString stringWithUTF8String:words[i].c_str()];
		[array addObject:word];
	}
	return [array autorelease];
	
}