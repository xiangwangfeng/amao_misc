

const express = require('express')
const auth = require('./auth')
const session = require('express-session')
const bodyParser = require('body-parser')
const fileStore = require('session-file-store')(session);
const cookieParser = require('cookie-parser')
const fs = require('fs')

const app = express()

app.use(express.static('public'))
app.use(bodyParser.urlencoded({ extended : false}))
app.use(bodyParser.json())
app.use(cookieParser())
app.use(session({
    name    :   'amao_session_id',
    secret  :    'amao sign key',
    store   :   new fileStore(),
    cookie  :   { maxAge : 1000 * 10},
    saveUninitialized : true,
    resave  : true,
}))

app.use(auth)

app.get('/',function(req,res){

    const path = __dirname + '/public/homepage.html'
    fs.readFile(path,function(err,data) {

        const user = req.session.user
        let content = data.toString()
        content = content.replace(new RegExp('{{NAME}}','g'),user)

        res.send(content)
        res.end()
    })
})




app.listen(3000)
