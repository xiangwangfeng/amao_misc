//
//  M80ImageFingerprint.m
//  M80Image
//
//  Created by amao on 11/18/15.
//  Copyright © 2015 Netease. All rights reserved.
//

#import "M80ImageFingerprint.h"
#import <zlib.h>

@implementation M80ImageFingerprint
+ (instancetype)fingerprint:(UIImage *)image
{
    M80ImageFingerprint *instance = [[M80ImageFingerprint alloc] init];
    [instance cal1:image];
    return instance;
}

- (void)cal:(UIImage *)image
{
    NSLog(@"begin  brightness");
    NSMutableArray *array = [NSMutableArray array];
    CFDataRef pixelData = CGDataProviderCopyData(CGImageGetDataProvider(image.CGImage));
    const UInt8* data = CFDataGetBytePtr(pixelData);
    NSInteger height = image.size.height;
    NSInteger width = image.size.width;
    
    for (NSInteger y = 0; y < height; y++)
    {
        NSMutableData *cacheData = [[NSMutableData alloc]init];
        @autoreleasepool {
            NSInteger lineOffset = y * width * 4;
            for (NSInteger x = 0; x < width; x++)
            {
                UInt8 red = data[lineOffset + x * 4];
                UInt8 green = data[lineOffset + x * 4 + 1];
                UInt8 blue = data[lineOffset + x * 4 + 2];
                
                UInt8 brightness =(UInt8)(0.299 * red + 0.587 * green + 0.114 *blue);
                [cacheData appendBytes:&brightness length:sizeof(UInt8)];
            }
        }
        uLong print = crc32(0, [cacheData bytes], (uInt)[cacheData length]);
        [array addObject:@(print)];
    }
    _lines = array;
    CFRelease(pixelData);
    NSLog(@"end  brightness");
}

- (void)cal1:(UIImage *)image
{
    NSLog(@"begin data");
    NSMutableArray *array = [NSMutableArray array];
    CFDataRef pixelData = CGDataProviderCopyData(CGImageGetDataProvider(image.CGImage));
    const UInt8* data = CFDataGetBytePtr(pixelData);
    NSInteger height = image.size.height;
    NSInteger width = image.size.width;
    
    for (NSInteger y = 0; y < height; y++)
    {
        NSData *cacheData = [NSData dataWithBytes:data + y * width * 4
                                           length:width * 4];
        uLong print = crc32(0, [cacheData bytes], (uInt)[cacheData length]);
        [array addObject:@(print)];
    }
    _lines = array;
    CFRelease(pixelData);
    NSLog(@"end data");
}
@end
