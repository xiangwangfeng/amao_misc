//
//  ModuleA.m
//  ModuleA
//
//  Created by amao on 16/1/31.
//  Copyright © 2016年 NTES. All rights reserved.
//

#import "ModuleA.h"

@implementation ModuleA
+ (NSBundle *)bundle
{
    return [NSBundle bundleWithURL:[[NSBundle mainBundle] URLForResource:@"ModuleABundle" withExtension:@"bundle"]];;
}
@end
