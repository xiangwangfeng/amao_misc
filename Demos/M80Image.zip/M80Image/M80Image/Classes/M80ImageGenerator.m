//
//  M80ImageGenerator.m
//  M80Image
//
//  Created by amao on 11/18/15.
//  Copyright © 2015 Netease. All rights reserved.
//

#import "M80ImageGenerator.h"
#import "M80ImageMergeInfo.h"
#import "UIImage+M80.h"



@implementation M80ImageGenerator
- (BOOL)feedImages:(NSArray *)images
{
    for (UIImage *image in images)
    {
        @autoreleasepool
        {
            if (![self feedImage:image])
            {
                return NO;
            }
        }
    }
    return YES;
}

- (BOOL)feedImage:(UIImage *)image
{
    BOOL success = NO;
    if (image)
    {
        if (_image == nil)
        {
            _image = image;
            success = YES;
        }
        else
        {
            success = [self doFeedImage:image];
        }
    }
    return success;
}

- (BOOL)doFeedImage:(UIImage *)image
{
    NSLog(@"feed image begin");
    BOOL imageValid = image.size.width == _image.size.width &&
    image.scale == _image.scale;
    if (imageValid)
    {
        NSLog(@"step1");
        M80ImageMergeInfoGenerator *generator =  [[M80ImageMergeInfoGenerator alloc] init];
        M80ImageMergeInfo *info = [generator infoByImage:_image
                                              secondImage:image];
        NSLog(@"step2");
        [self drawImage:info];
        NSLog(@"step3");
    }
    NSLog(@"feed image end");
    return imageValid;
}



- (void)drawImage:(M80ImageMergeInfo *)info
{
    @autoreleasepool
    {
        NSLog(@"draw");
        UIImage *firstImage = info.firstImage;
        UIImage *secondImage= info.secondImage;
        
        UIGraphicsBeginImageContextWithOptions(info.size, NO, info.firstImage.scale);
        
        
        [firstImage drawInRect:CGRectMake(0, 0, firstImage.size.width, firstImage.size.height)];
        UIImage *subSecondImage = [secondImage m80_subImage:CGRectMake(0, info.secondMatchedRange.location, secondImage.size.width, secondImage.size.height - info.secondMatchedRange.location)];
        
        [subSecondImage drawInRect:CGRectMake(0, info.firstMatchedRange.location, subSecondImage.size.width, subSecondImage.size.height)];
        
        
        UIImage *result = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        _image = result;
        NSLog(@"draw end");

    }
}
@end
