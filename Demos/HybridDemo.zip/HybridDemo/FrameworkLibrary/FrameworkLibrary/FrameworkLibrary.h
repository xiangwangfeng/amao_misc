//
//  FrameworkLibrary.h
//  FrameworkLibrary
//
//  Created by amao on 2016/10/14.
//  Copyright © 2016年 amao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FrameworkLibrary.
FOUNDATION_EXPORT double FrameworkLibraryVersionNumber;

//! Project version string for FrameworkLibrary.
FOUNDATION_EXPORT const unsigned char FrameworkLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrameworkLibrary/PublicHeader.h>
#import <FrameworkLibrary/ClassA.h>

