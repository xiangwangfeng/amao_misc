//
//  ViewController.m
//  WebViewCrashDemo
//
//  Created by amao on 12/8/14.
//  Copyright (c) 2014 amao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIWebView *myWebView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    NSURL *url = [NSURL URLWithString:@"http://yxs.im/HErUq2"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [_myWebView loadRequest:request];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)webView:(UIWebView *)webView
shouldStartLoadWithRequest:(NSURLRequest *)request
 navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *host = [[request URL] host];
    static NSString *testTag = @"test_tag";
    
    if ([host hasSuffix:@"yixin.im"])
    {
        if ([[request allHTTPHeaderFields] objectForKey:testTag] == nil)
        {
            NSMutableURLRequest *aRequest = [request mutableCopy];
            [aRequest addValue:@"1" forHTTPHeaderField:testTag];
            [webView loadRequest:aRequest];            
            return NO;
        }
    }

    else
    {
        if ([[request allHTTPHeaderFields] objectForKey:testTag])
        {
            NSMutableURLRequest *aRequest = [request mutableCopy];
            [aRequest addValue:nil forHTTPHeaderField:testTag];
            [webView loadRequest:aRequest];
            return NO;
        }
    }
    return YES;
    
}

@end
