#include "StdAfx.h"
#include "ITaskBarList.h"
#include "ProgressTaskBar.h"


#define WM_PROGRESSTASKBAR_PROGRESS  (WM_USER+0x100)
#define WM_PROGRESSTASKBAR_RESET	 (WM_USER+0x101)
#define WM_PROGRESSTASKBAR_SETICON	 (WM_USER+0x102)
#define ASSERT_VOID(p)      {ASSERT(p); if (!p) {return;}}


BEGIN_MESSAGE_MAP(CProgressTaskBar,CWnd)
	ON_MESSAGE(WM_PROGRESSTASKBAR_PROGRESS,OnUpdateProgress)
	ON_MESSAGE(WM_PROGRESSTASKBAR_RESET,OnResetProgress)
	ON_MESSAGE(WM_PROGRESSTASKBAR_SETICON,OnSetTaskbarIcon)
END_MESSAGE_MAP()

CProgressTaskBar::CProgressTaskBar(HWND hWnd)
{
	m_hTargetWnd	= hWnd;
	m_lfProgress	= 0.0;
	m_pTaskBarList	= NULL;
	m_bInit			= FALSE;
	m_hIcon			= NULL;
}

CProgressTaskBar::~CProgressTaskBar(void)
{
	if (m_pTaskBarList)
	{
		m_pTaskBarList->Release();
	}
}



BOOL	CProgressTaskBar::Init()
{
	CString csWinClassName = ::AfxRegisterWndClass(NULL);
	BOOL bRet = __super::CreateEx(0,csWinClassName,_T("CProgressTaskbarWnd"),
		0 ,0 ,0 ,0 ,0 ,HWND_MESSAGE,0);

	BOOL bWin7 = IsWin7();

	HRESULT hr =  CoCreateInstance(CLSID_TaskbarList,0,CLSCTX_INPROC_SERVER, 
									__uuidof(ITaskbarList3),(void**)&m_pTaskBarList);

	m_bInit = bRet && bWin7 && SUCCEEDED(hr);
	if (m_bInit)
	{
		Reset();
	}
	return m_bInit;
}

BOOL	CProgressTaskBar::IsWin7()
{
	BOOL bGetVersion = TRUE;
	OSVERSIONINFOEX   osvi;   

	ZeroMemory(&osvi,sizeof(OSVERSIONINFOEX));   
	osvi.dwOSVersionInfoSize=sizeof(OSVERSIONINFOEX);   

	if(!GetVersionEx((OSVERSIONINFO*)&osvi))
	{   
		osvi.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);   
		if  (!GetVersionEx((OSVERSIONINFO*)&osvi))     
		{
			bGetVersion = FALSE;
		}   
	}   
	return bGetVersion && osvi.dwMajorVersion == 6 &&  osvi.dwMinorVersion ==1;
}

void	CProgressTaskBar::SetProgress(double lfProgress)
{
	ASSERT_VOID(m_bInit);
	m_lfProgress = lfProgress;
	SendMessage(WM_PROGRESSTASKBAR_PROGRESS);
}

void	CProgressTaskBar::Reset()
{
	ASSERT_VOID(m_bInit);
	m_lfProgress = 0.0;
	SendMessage(WM_PROGRESSTASKBAR_RESET);
}

void	CProgressTaskBar::SetTaskBarIcon(HICON hIcon,const CString& csDescription)
{
	ASSERT_VOID(m_bInit);
	m_csDescription = csDescription;
	m_hIcon			= hIcon;
	SendMessage(WM_PROGRESSTASKBAR_SETICON);
}

LRESULT	CProgressTaskBar::OnResetProgress(WPARAM wParam, LPARAM lParam)
{
	if (m_pTaskBarList)
	{
		m_pTaskBarList->SetOverlayIcon(m_hTargetWnd,NULL,_T(""));
		m_pTaskBarList->SetProgressState(m_hTargetWnd,TBPF_NOPROGRESS);
		m_pTaskBarList->SetProgressState(m_hTargetWnd,TBPF_NORMAL);
	}
	return 0L;
}


LRESULT	CProgressTaskBar::OnUpdateProgress(WPARAM wParam, LPARAM lParam)
{
	if (m_pTaskBarList)
	{
		m_pTaskBarList->SetProgressValue(m_hTargetWnd,(ULONGLONG)(100*m_lfProgress),(ULONGLONG)100);
	}
	return 0L;
}

LRESULT	CProgressTaskBar::OnSetTaskbarIcon(WPARAM wParam, LPARAM lParam)
{
	if (m_pTaskBarList)
	{
		m_pTaskBarList->SetOverlayIcon(m_hTargetWnd,m_hIcon,m_csDescription);
	}
	return 0L;
}

