//
//  M80ImageMergeInfo.h
//  M80Image
//
//  Created by amao on 11/18/15.
//  Copyright © 2015 Netease. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface M80ImageMergeInfo : NSObject
@property (nonatomic,strong)    UIImage     *firstImage;
@property (nonatomic,strong)    UIImage     *secondImage;
@property (nonatomic,assign)    CGSize      size;
@property (nonatomic,assign)    NSRange     firstMatchedRange;
@property (nonatomic,assign)    NSRange     secondMatchedRange;
@end


@interface M80ImageMergeInfoGenerator : NSObject
- (M80ImageMergeInfo *)infoByImage:(UIImage *)firstImage
                       secondImage:(UIImage *)secondImage;
@end