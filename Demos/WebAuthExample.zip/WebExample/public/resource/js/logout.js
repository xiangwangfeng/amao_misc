document.onreadystatechange = ()=> {
    if(document.readyState == 'complete')
    {
        const button = document.getElementById('logout')
        button.addEventListener('click',()=>{
        
            fetch('/logout',{
                method : 'GET',
                headers : {
                    'Content-Type'  : 'application/json'
                },
                credentials : 'include',
            }).then(res => {
                window.location.href = '/'
            })
        });
    }
}