//
//  expression_calc.hpp
//  LLDemo
//
//  Created by amao on 2020/1/13.
//  Copyright © 2020 amao. All rights reserved.
//

#ifndef expression_calc_hpp
#define expression_calc_hpp

#include <stdio.h>
#include "token_parser.hpp"

class Expression
{
public:
    double run(const std::vector<Token> &tokens);
private:
    double factor();
    double term();
    double expr();
private:
    size_t current_;
    std::vector<Token> tokens_;
};

#endif /* expression_calc_hpp */
