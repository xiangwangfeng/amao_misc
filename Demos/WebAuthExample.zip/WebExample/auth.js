let sessions = {admin : {name : '管理员',
                        password : '123456'},
                amao : {name : '阿毛',
                        password : '123456'},        
                                }
const auth = function(req,res,next){

    const path = req.path
    if(path == '/login')
    {
        if(req.method == 'POST') 
        {
            const usernameValue = req.body.username
            const passwordValue = req.body.password


            if(usernameValue != null && 
               passwordValue != null &&
               sessions[usernameValue] != null &&
               sessions[usernameValue].password == passwordValue)
            {
                const name = sessions[usernameValue].name
                console.log('match and name is ' + name)
                req.session.user = name
                res.send('200')
                res.end()                      
            }
            else
            {
                res.send('302')
                res.end()
                return
            }
        }
        else
        {
            res.sendFile(__dirname +  '/public/login.html')
        }
    }
    else if(path == '/login_failed')
    {
        res.sendFile(__dirname +  '/public/login_failed.html')
    }
    else if(path == '/logout') 
    {
        console.log('enter logout')
        req.session.destroy(function(err){
            res.send('hahha')
            res.end()
        })
    }
    else
    {
        if(logined(req)) 
        {
            next();
        }
        else
        {
            res.redirect('/login')
        }
    }
}

function logined(req) 
{
    console.dir(req.session)
    const user = req.session.user
    console.dir('session user ' + user)
    if(user != null) {
        req.session.touch()
    }
    return user != null
}

module.exports = auth