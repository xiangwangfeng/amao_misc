//
//  expression_calc.cpp
//  LLDemo
//
//  Created by amao on 2020/1/13.
//  Copyright © 2020 amao. All rights reserved.
//

#include "expression_calc.hpp"

double Expression::run(const std::vector<Token> &tokens)
{
    tokens_ = tokens;
    current_ = 0;
    
    return expr();
}

double Expression::expr()
{
    double exp = term();
    while (current_ < tokens_.size() &&
           (tokens_[current_].type_ == kTokenTypeAdd ||
           tokens_[current_].type_ == kTokenTypeMinus))
    {
        TokenType type = tokens_[current_].type_;
        current_++;
        double new_exp = term();
        if (type == kTokenTypeAdd)
        {
            exp = exp + new_exp;
        }
        else
        {
            exp = exp - new_exp;
        }
    }
    return exp;
}


double Expression::term()
{
    double exp = factor();
    while (current_ < tokens_.size() &&
           (tokens_[current_].type_ == kTokenTypeMul ||
           tokens_[current_].type_ == kTokenTypeDiv))
    {
        TokenType type = tokens_[current_].type_;
        current_++;
        double new_exp = factor();
        if (type == kTokenTypeMul)
        {
            exp = exp * new_exp;
        }
        else
        {
            exp = exp / new_exp;
        }
    }
    return exp;
}

double Expression::factor()
{
    if (current_ < tokens_.size())
    {
        if (tokens_[current_].type_ == kTokenNumber)
        {
            double v = tokens_[current_].value_;
            current_++;
            return v;
        }
        else if (tokens_[current_].type_ == kTokenLP)
        {
            current_++;
            double v = expr();
            current_++; //skip rp...
            return v;
        }
    }
    return 0.0;
}
