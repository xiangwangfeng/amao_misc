//
//  main.m
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
