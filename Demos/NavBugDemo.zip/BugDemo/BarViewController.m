//
//  BarViewController.m
//  BugDemo
//
//  Created by amao on 3/28/14.
//  Copyright (c) 2014 amao. All rights reserved.
//

#import "BarViewController.h"

@interface BarViewController ()

@end

@implementation BarViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    static int i = 0;
    NSString *text = [NSString stringWithFormat:@"Bar %@ ViewController %d",_hasBar ? @"" : @"Less",i++];
    self.title = text;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回"
                                                                            style:UIBarButtonItemStyleBordered
                                                                           target:self
                                                                           action:@selector(back:)];
}

- (void)back: (id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:!_hasBar
                                              animated:animated];
}
- (IBAction)pushBarView:(id)sender
{
    BarViewController *vc = [BarViewController new];
    vc.hasBar = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)pushBarLessView:(id)sender
{
    BarViewController *vc = [BarViewController new];
    vc.hasBar = NO;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
