//
//  ViewController.m
//  M80Image
//
//  Created by amao on 11/18/15.
//  Copyright © 2015 Netease. All rights reserved.
//

#import "ViewController.h"
#import "M80ImageGenerator.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *firstImageView;
@property (weak, nonatomic) IBOutlet UIImageView *secondImageView;
@property (weak, nonatomic) IBOutlet UIImageView *thirdImageView;
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _firstImageView.image = [UIImage imageNamed:@"1.png"];
    _secondImageView.image= [UIImage imageNamed:@"2.png"];
    _thirdImageView.image = [UIImage imageNamed:@"3.png"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onButtonPressed:(id)sender {

    M80ImageGenerator *generator = [[M80ImageGenerator alloc] init];
    [generator feedImage:_firstImageView.image];
    [generator feedImage:_secondImageView.image];
    [generator feedImage:_thirdImageView.image];

    _resultImageView.image = generator.image;
}


@end
