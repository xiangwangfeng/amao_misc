//
//  token_parser.cpp
//  LLDemo
//
//  Created by amao on 2020/1/13.
//  Copyright © 2020 amao. All rights reserved.
//

#include "token_parser.hpp"

std::vector<Token>  TokenParser::parse(const std::string &exp)
{
    std::vector<Token> tokens;
    size_t length = exp.length();
    size_t index = 0;
    while (index < length)
    {
        char c = exp[index];
        if (c >= '0' && c <= '9')
        {
            double value = parse_number(exp, &index);
            Token token;
            token.type_ = kTokenNumber;
            token.value_ = value;
            tokens.push_back(token);
        }
        else
        {
            switch (c) {
                case '+':
                {
                    Token token;
                    token.type_ = kTokenTypeAdd;
                    tokens.push_back(token);
                }
                    break;
                case '-':
                {
                    Token token;
                    token.type_ = kTokenTypeMinus;
                    tokens.push_back(token);
                }
                    break;
                case '*':
                {
                    Token token;
                    token.type_ = kTokenTypeMul;
                    tokens.push_back(token);
                }
                    break;
                case '/':
                {
                    Token token;
                    token.type_ = kTokenTypeDiv;
                    tokens.push_back(token);
                }
                    break;
                case '(':
                {
                    Token token;
                    token.type_ = kTokenLP;
                    tokens.push_back(token);
                }
                    break;
                case ')':
                {
                    Token token;
                    token.type_ = kTokenRP;
                    tokens.push_back(token);
                }
                    break;
                default:
                    break;
            }
            index++;
        }
    }
    return tokens;
}

double TokenParser::parse_number(const std::string &exp, size_t *index)
{
    size_t i = *index;
    char c = exp[i];
    double result = 0;
    while (c >= '0' && c <= '9')
    {
        result = result * 10 + (c - '0');
        i++;
        c = exp[i];
    }
    *index = i;
    return result;
}
