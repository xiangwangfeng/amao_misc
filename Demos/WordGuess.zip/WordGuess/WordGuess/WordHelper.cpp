//
//  WordHelper.cpp
//  WordGuess
//
//  Created by amao on 3/27/12.
//  Copyright (c) 2012 Netease. All rights reserved.
//

#include "WordHelper.h"

WordHelper::WordHelper()
{
	
}


WordHelper::~WordHelper()
{

}

void	WordHelper::InitDic(const char *filepath)
{
	tree_.ReadDicFromFile(filepath);
}

void	WordHelper::FindAllWords(const std::vector<char> &characters,size_t word_length,std::vector<std::string> &words)
{
	if (word_length > characters.size() ||
		HasInvalidCharacter(characters))
	{
		return;
	}
	words_ = &words;
	FindAllWords(characters,word_length,"");
}

bool	WordHelper::HasInvalidCharacter(const std::vector<char> &characters)
{
	for (size_t i = 0; i < characters.size(); i++) 
	{
		char ch = characters[i];
		if (!(ch >= 'a' && ch <= 'z')) 
		{
			return true;
		}
	}
	return false;
}

void	WordHelper::FindAllWords(const std::vector<char>& characters,size_t word_length,const std::string& word_header)
{

	for (size_t i = 0; i < characters.size(); i++)
	{
		std::vector<char> temp_characters = characters;
		temp_characters.erase(temp_characters.begin() + i);

		std::string temp_word_header = word_header;
		temp_word_header.push_back(characters[i]);



		if (temp_word_header.length() == word_length)
		{
			if (tree_.Contains(temp_word_header,true))
			{
				TryToPushStringToVector(temp_word_header);
			}
		}
		else
		{
			if (tree_.Contains(temp_word_header))
			{
				FindAllWords(temp_characters,word_length,temp_word_header);
			}	
		}
		
	}
}


void	WordHelper::TryToPushStringToVector(const std::string &word)
{
	for (size_t i = 0; i < words_->size(); i ++)
	{
		std::string &word_in_vector = (*words_)[i];
		if (word_in_vector.compare(word) == 0)
		{
			return;
		}
	}
	words_->push_back(word);
	
}
