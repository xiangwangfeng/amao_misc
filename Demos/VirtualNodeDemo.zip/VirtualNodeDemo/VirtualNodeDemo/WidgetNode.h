//
//  WidgetNode.h
//  VirtualNodeDemo
//
//  Created by amao on 2020/1/8.
//  Copyright © 2020 amao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WidgetNode : NSObject

@property (nonatomic,strong)    NSMutableArray<WidgetNode *> *children;

//sample 
@property (nonatomic,assign)    NSInteger   backgroundColorIndex;
@property (nonatomic,assign)    CGRect      frame;

- (UIView *)nodeView;
- (void)updateView:(UIView *)view;
@end

NS_ASSUME_NONNULL_END
