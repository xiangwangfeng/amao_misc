//
//  main.cpp
//  HamiltonDemo
//
//  Created by amao on 2020/1/10.
//  Copyright © 2020 amao. All rights reserved.
//

#include <iostream>
static int paths = 0;
int matrix[3][6] = {{0,0,0,0,0,0},
                    {0,0,0,0,0,0},
                    {0,0,0,0,0,0}
};


void log_matrix()
{
    printf("**--------------**\n");
    for (int x = 0 ; x < 3; x++)
    {
        for (int y = 0; y < 6; y++)
        {
            printf("%d",matrix[x][y]);
            if (y != 5)
            {
                printf("-");
            }
        }
        printf("\n");
    }
    paths++;
}

bool can_fire(int x,int y) {
    return x >= 0 && x < 3 && y >= 0 && y < 6 && matrix[x][y] == 0;
}

void fire(int x,int y,int n) {
    matrix[x][y] = n;
    if (n == 18)
    {
        log_matrix();
    }
    else
    {
        {
            int new_x = x + 1;
            int new_y = y;
            if (can_fire(new_x, new_y))
            {
                fire(new_x, new_y, n+1);
            }
        }
        {
            int new_x = x - 1;
            int new_y = y;
            if (can_fire(new_x, new_y))
            {
                fire(new_x, new_y, n+1);
            }
        }
        {
            int new_x = x;
            int new_y = y + 1;
            if (can_fire(new_x, new_y))
            {
                fire(new_x, new_y, n+1);
            }
        }
        {
            int new_x = x;
            int new_y = y - 1;
            if (can_fire(new_x, new_y))
            {
                fire(new_x, new_y, n+1);
            }
        }
    }
    matrix[x][y] = 0;
}





int main(int argc, const char * argv[]) {
    for (int x = 0 ; x < 3; x++) {
        for (int y = 0; y < 6; y++)
        {
            fire(x, y, 1);
        }
    }
    printf("total paths %d",paths);
}
