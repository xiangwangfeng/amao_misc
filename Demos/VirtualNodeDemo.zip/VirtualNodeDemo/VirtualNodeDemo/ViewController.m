//
//  ViewController.m
//  VirtualNodeDemo
//
//  Created by amao on 2020/1/8.
//  Copyright © 2020 amao. All rights reserved.
//

#import "ViewController.h"
#import "WidgetNode.h"

@interface ViewController ()
@property (nonatomic,strong)    WidgetNode  *mainNode;
@property (nonatomic,strong)    UIView *mainNodeView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.mainNode = [self generateMainNode];
    self.mainNodeView = self.mainNode.nodeView;
    [self.view addSubview:self.mainNodeView];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSInteger index = arc4random() % 10;
        for (WidgetNode *node in self.mainNode.children) {
            node.backgroundColorIndex = index++;
        }
        [self.mainNode updateView:self.mainNodeView];
        
    });
}

- (WidgetNode *)generateMainNode
{
    WidgetNode *node = [self generateNode];
    node.frame = CGRectMake(0, 100, 320, 200);
    
    for (NSInteger i = 0; i < 5; i ++)
    {
        WidgetNode *subNode = [self generateNode];
        subNode.frame = CGRectMake(0 + 320 / 5 * i, 0, 320 / 5, 200);
        [node.children addObject:subNode];
    }
    return node;
}


- (WidgetNode *)generateNode
{
    static NSInteger  bkIndex = 0;
    bkIndex++;
    WidgetNode *node = [WidgetNode new];
    node.backgroundColorIndex = bkIndex;
    return node;
}
@end
