#include "AffineTransform.h"
#include <Windows.h>
#include <iostream>


int main()
{
	POINT point,copyPoint;
	point.x = 5;
	point.y = 6;
	

	//ƽ��
	AffineTransform translation = AffineTransform::translation(-1.1f,22.f);
	copyPoint = point;
	translation.transformPoint<LONG>(copyPoint.x,copyPoint.y);
	std::cout<<"after translation, point is ("<<copyPoint.x<<","<<copyPoint.y<<")"<<std::endl;

	//��ת
	const float PI = 3.14159265358979323846f;
	AffineTransform rotation = AffineTransform::rotation(PI / 4,7.f,23.f);
	copyPoint = point;
	rotation.transformPoint<LONG>(copyPoint.x,copyPoint.y);
	std::cout<<"after rotation, point is ("<<copyPoint.x<<","<<copyPoint.y<<")"<<std::endl;

	//����
	AffineTransform scalation = AffineTransform::scale(20.f,2.f);
	copyPoint = point;
	scalation.transformPoint<LONG>(copyPoint.x,copyPoint.y);
	std::cout<<"after scalation, point is ("<<copyPoint.x<<","<<copyPoint.y<<")"<<std::endl;


	system("pause");
	return 0;
}