//
//  ViewController.h
//  HostApp
//
//  Created by amao on 16/1/31.
//  Copyright © 2016年 NTES. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController


@end

