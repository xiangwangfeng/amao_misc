//
//  main.cpp
//  LLDemo
//
//  Created by amao on 2020/1/13.
//  Copyright © 2020 amao. All rights reserved.
//

#include <iostream>
#include "token_parser.hpp"
#include "expression_calc.hpp"



int main(int argc, const char * argv[]) {
    // insert code here...
    std::vector<Token> tokens = TokenParser::parse("433 + 23 * (23 + 7) / 2 + 30"); //808
    Expression runner;
    double result = runner.run(tokens);
    printf("result %lf",result);
    return 0;
}
