//
//  ModuleA.h
//  ModuleA
//
//  Created by amao on 16/1/31.
//  Copyright © 2016年 NTES. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ModuleA : NSObject
+ (NSBundle *)bundle;
@end
