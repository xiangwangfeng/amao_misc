//
//  ModuleAViewController.m
//  ModuleA
//
//  Created by amao on 16/1/31.
//  Copyright © 2016年 NTES. All rights reserved.
//

#import "ModuleAViewController.h"
#import "ModuleA.h"

@interface ModuleAViewController ()
@property (nonatomic,strong)    UIImageView *imageView;
@end

@implementation ModuleAViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"Module A ViewController";

    _imageView = [[UIImageView alloc] init];
    [self.view addSubview:_imageView];
    
    
    NSBundle *bundle = [ModuleA bundle];
    NSString *path = [bundle pathForResource:@"icon" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _imageView.image = image;
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    UIImage *image = _imageView.image;
    CGFloat scale = [[UIScreen mainScreen] scale];
    CGFloat width =  image.size.width * image.scale /scale;
    CGFloat height = image.size.height * image.scale / scale;
    [_imageView setFrame:CGRectMake((self.view.bounds.size.width - width)/2, (self.view.bounds.size.height - height)/2, width, height)];
}

@end
